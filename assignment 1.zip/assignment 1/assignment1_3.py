# Q.3]:

def display(n1,n2):
    ans=n1+n2
    return ans

def add():
    a=int(input("enter a number : "))
    b=int(input("enter 2nd number :"))
    
    print(display(a,b))

if __name__=="__main__":
    add()