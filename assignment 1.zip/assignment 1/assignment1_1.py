# Q. 1 - ANSWER

def fun ():
    print("Hello from fun ")
if __name__ == "__main__":
    fun()
