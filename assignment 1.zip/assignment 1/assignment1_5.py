# Q. 5
def main():
    for i in range(10,0,-1):
        print(i)
if __name__=="__main__":
    main()

