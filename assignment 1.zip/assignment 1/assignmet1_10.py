# Q. 10

def display(b):
    return len(b)
def main():
    
    print(display(input("enter a string  = ")))
if __name__=="__main__":
    main()