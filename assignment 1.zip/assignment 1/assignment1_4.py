# Q.4
def main():
    i=1
    while i<=5:
        print("Marvelleous")
        i+=1

if __name__=="__main__":
    main()